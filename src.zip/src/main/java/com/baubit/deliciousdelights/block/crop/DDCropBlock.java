package com.baubit.deliciousdelights.block.crop;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.function.Supplier;

public class DDCropBlock extends CropBlock {
    private final int maxAge;
    private final VoxelShape[] shapes;
    private final Supplier<ItemLike> seedsItemSupplier;
    private final Supplier<ItemLike> cropItemSupplier;
    private final int minDrop;
    private final int maxDrop;

    public DDCropBlock(String name, int maxAge, VoxelShape[] shapes, Supplier<ItemLike> seedsItemSupplier, Supplier<ItemLike> cropItemSupplier) {
        this(name, maxAge, shapes, seedsItemSupplier, cropItemSupplier, 1, 3);
    }

    public DDCropBlock(String name, int maxAge, VoxelShape[] shapes, Supplier<ItemLike> seedsItemSupplier, Supplier<ItemLike> cropItemSupplier, int minDrop, int maxDrop) {
        super(Properties.of()
                .noCollission()
                .randomTicks()
                .instabreak());
        this.maxAge = maxAge;
        this.shapes = shapes;
        this.seedsItemSupplier = seedsItemSupplier;
        this.cropItemSupplier = cropItemSupplier;
        this.minDrop = minDrop;
        this.maxDrop = maxDrop;
    }

    @Override
    public IntegerProperty getAgeProperty() {
        return AGE;
    }

    @Override
    public int getMaxAge() {
        return maxAge;
    }

    @Override
    protected ItemLike getBaseSeedId() {
        return seedsItemSupplier.get();
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        int age = state.getValue(this.getAgeProperty());
        if (age < shapes.length) {
            return shapes[age];
        }
        return shapes[shapes.length - 1];
    }

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (random.nextInt(3) == 0) {
            super.randomTick(state, level, pos, random);
        }
    }

    public ItemLike getCropItem() {
        return cropItemSupplier.get();
    }

    public int getMinDrop() {
        return minDrop;
    }

    public int getMaxDrop() {
        return maxDrop;
    }
}
