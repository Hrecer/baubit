package com.baubit.deliciousdelights.item.base;

import net.minecraft.world.item.Item;

public class DDItemBase extends Item {
    public DDItemBase(String name) {
        super(new Properties());
    }

    public DDItemBase(String name, boolean keepWhenCrafting) {
        super(new Properties()
                .durability(keepWhenCrafting ? 64 : 0));
    }

    public DDItemBase(String name, int maxStackSize) {
        super(new Properties()
                .stacksTo(maxStackSize));
    }

    public DDItemBase(String name, int maxStackSize, boolean keepWhenCrafting) {
        super(new Properties()
                .stacksTo(maxStackSize)
                .durability(keepWhenCrafting ? 64 : 0));
    }
}
