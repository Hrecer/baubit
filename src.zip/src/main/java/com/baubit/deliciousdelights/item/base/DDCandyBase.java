package com.baubit.deliciousdelights.item.base;

import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;

public class DDCandyBase extends Item {
    private final int useDuration;

    public DDCandyBase(String name, int nutrition, float saturation, int useDuration) {
        super(new Properties()
                .food(new FoodProperties.Builder()
                        .nutrition(nutrition)
                        .saturationMod(saturation)
                        .fast()
                        .build()));
        this.useDuration = useDuration;
    }

    public DDCandyBase(String name, int nutrition, float saturation, int useDuration, String specialThanks) {
        super(new Properties()
                .food(new FoodProperties.Builder()
                        .nutrition(nutrition)
                        .saturationMod(saturation)
                        .fast()
                        .build()));
        this.useDuration = useDuration;
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return useDuration;
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.EAT;
    }
}
