package com.baubit;

import com.baubit.deliciousdelights.init.DDBlockInit;
import com.baubit.deliciousdelights.init.DDItemInit;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(BaubitMainJava.MOD_ID)
public class BaubitMainJava {
    public static final String MOD_ID = "baubit";

    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MOD_ID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);

    // 定义四类食物的共同效果
    private static final MobEffectInstance[] GOLDEN_EFFECTS = {
        new MobEffectInstance(MobEffects.ABSORPTION, 2400, 0),
        new MobEffectInstance(MobEffects.REGENERATION, 100, 1)
    };

    private static final MobEffectInstance[] DIAMOND_EFFECTS = {
        new MobEffectInstance(MobEffects.ABSORPTION, 3000, 1),
        new MobEffectInstance(MobEffects.REGENERATION, 200, 1),
        new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 600, 0)
    };

    private static final MobEffectInstance[] POWERED_EFFECTS = {
        new MobEffectInstance(MobEffects.ABSORPTION, 2400, 1),
        new MobEffectInstance(MobEffects.REGENERATION, 600, 3),
        new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 6000, 0),
        new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 6000, 0)
    };

    private static final MobEffectInstance[] OVERPOWERED_EFFECTS = {
        new MobEffectInstance(MobEffects.DAMAGE_BOOST, 1200, 0),
        new MobEffectInstance(MobEffects.ABSORPTION, 4800, 3),
        new MobEffectInstance(MobEffects.REGENERATION, 900, 0),
        new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 7800, 0),
        new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 7200, 2),
        new MobEffectInstance(MobEffects.NIGHT_VISION, 8400, 0)
    };

    // 金食物: 4饥饿, 16饱和度
    public static final RegistryObject<Item> GOLDEN_BREAD = registerFood("golden_bread", 4, 4.0F, GOLDEN_EFFECTS);
    public static final RegistryObject<Item> GOLDEN_COOKIE = registerFood("golden_cookie", 4, 4.0F, GOLDEN_EFFECTS);
    public static final RegistryObject<Item> GOLDEN_MELON = registerFood("golden_melon_slice", 4, 4.0F, GOLDEN_EFFECTS);
    public static final RegistryObject<Item> GOLDEN_POTATO = registerFood("golden_potato", 4, 4.0F, GOLDEN_EFFECTS);
    public static final RegistryObject<Item> GOLDEN_PUMPKIN = registerFood("golden_pumpkin_pie", 4, 4.0F, GOLDEN_EFFECTS);

    // 钻石: 5饥饿, 30饱和度
    public static final RegistryObject<Item> DIAMOND_APPLE = registerFood("diamond_apple", 5, 6.0F, DIAMOND_EFFECTS);
    public static final RegistryObject<Item> DIAMOND_BREAD = registerFood("diamond_bread", 5, 6.0F, DIAMOND_EFFECTS);
    public static final RegistryObject<Item> DIAMOND_COOKIE = registerFood("diamond_cookie", 5, 6.0F, DIAMOND_EFFECTS);
    public static final RegistryObject<Item> DIAMOND_MELON = registerFood("diamond_melon_slice", 5, 6.0F, DIAMOND_EFFECTS);
    public static final RegistryObject<Item> DIAMOND_POTATO = registerFood("diamond_potato", 5, 6.0F, DIAMOND_EFFECTS);
    public static final RegistryObject<Item> DIAMOND_PUMPKIN = registerFood("diamond_pumpkin_pie", 5, 6.0F, DIAMOND_EFFECTS);

    // Powered: 6饥饿, 48饱和度
    public static final RegistryObject<Item> POWERED_APPLE = registerFood("powered_apple", 6, 8.0F, POWERED_EFFECTS);
    public static final RegistryObject<Item> POWERED_BREAD = registerFood("powered_bread", 6, 8.0F, POWERED_EFFECTS);
    public static final RegistryObject<Item> POWERED_COOKIE = registerFood("powered_cookie", 6, 8.0F, POWERED_EFFECTS);
    public static final RegistryObject<Item> POWERED_MELON = registerFood("powered_melon_slice", 6, 8.0F, POWERED_EFFECTS);
    public static final RegistryObject<Item> POWERED_POTATO = registerFood("powered_potato", 6, 8.0F, POWERED_EFFECTS);
    public static final RegistryObject<Item> POWERED_PUMPKIN = registerFood("powered_pumpkin_pie", 6, 8.0F, POWERED_EFFECTS);

    // Overpowered: 8饥饿, 80饱和度
    public static final RegistryObject<Item> OVERPOWERED_APPLE = registerFood("overpowered_apple", 8, 10.0F, OVERPOWERED_EFFECTS);
    public static final RegistryObject<Item> OVERPOWERED_BREAD = registerFood("overpowered_bread", 8, 10.0F, OVERPOWERED_EFFECTS);
    public static final RegistryObject<Item> OVERPOWERED_COOKIE = registerFood("overpowered_cookie", 8, 10.0F, OVERPOWERED_EFFECTS);
    public static final RegistryObject<Item> OVERPOWERED_MELON = registerFood("overpowered_melon_slice", 8, 10.0F, OVERPOWERED_EFFECTS);
    public static final RegistryObject<Item> OVERPOWERED_POTATO = registerFood("overpowered_potato", 8, 10.0F, OVERPOWERED_EFFECTS);
    public static final RegistryObject<Item> OVERPOWERED_PUMPKIN = registerFood("overpowered_pumpkin_pie", 8, 10.0F, OVERPOWERED_EFFECTS);

    // Apple Carrot: 8饥饿, 0.3饱和度 (从1.12.2移植)
    public static final RegistryObject<Item> APPLE_CARROT = registerSimpleFood("apple_carrot", 8, 0.3F);

    // Carrot Apple: 8饥饿, 0.3饱和度 (从1.12.2移植)
    public static final RegistryObject<Item> CARROT_APPLE = registerSimpleFood("carrot_apple", 8, 0.3F);

    // More Cookies 模组物品 (从1.12.2移植) - 合并到主文件
    // 木质/石质/铁质/金质/钻石曲奇
    public static final RegistryObject<Item> WOODEN_COOKIE = registerSimpleFood("wooden_cookie", 3, 0.3F);
    public static final RegistryObject<Item> STONE_COOKIE = registerSimpleFood("stone_cookie", 4, 0.3F);
    public static final RegistryObject<Item> IRON_COOKIE = registerSimpleFood("iron_cookie", 5, 0.3F);
    public static final RegistryObject<Item> GOLD_COOKIE = registerSimpleFood("gold_cookie", 4, 0.3F);
    public static final RegistryObject<Item> DIAMOND_COOKIE_MORE = registerSimpleFood("diamond_cookie_more", 8, 0.3F);

    // 特殊曲奇
    public static final RegistryObject<Item> BREAD_COOKIE = registerSimpleFood("bread_cookie", 6, 0.3F);
    public static final RegistryObject<Item> CARROT_COOKIE = registerSimpleFood("carrot_cookie", 5, 0.3F);
    public static final RegistryObject<Item> WATER_COOKIE = registerSimpleFood("water_cookie", 4, 0.3F);
    public static final RegistryObject<Item> WOOL_COOKIE = registerSimpleFood("wool_cookie", 3, 0.3F);
    public static final RegistryObject<Item> DOUBLE_COOKIE = registerSimpleFood("double_cookie", 4, 0.3F);

    // ========== Baubit 原创造模式标签页 (必须在所有物品定义之后) ==========
    public static final RegistryObject<CreativeModeTab> BAUBIT_TAB = TABS.register("baubit", () -> CreativeModeTab.builder()
            .icon(() -> new ItemStack(POWERED_APPLE.get()))
            .title(Component.translatable("itemGroup.baubit"))
            .displayItems((params, output) -> {
                ITEMS.getEntries().forEach(item -> output.accept(item.get()));
            })
            .build());

    private static RegistryObject<Item> registerFood(String name, int nutrition, float saturation, MobEffectInstance[] effects) {
        return ITEMS.register(name, () -> new FoodItem(nutrition, saturation, effects));
    }

    private static RegistryObject<Item> registerSimpleFood(String name, int nutrition, float saturation) {
        return ITEMS.register(name, () -> new SimpleFoodItem(nutrition, saturation));
    }

    public BaubitMainJava() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        // 注册 Baubit 原物品
        ITEMS.register(modEventBus);
        TABS.register(modEventBus);

        // 注册DeliciousDelights方块（先注册方块）
        DDBlockInit.register(modEventBus);

        // 注册DeliciousDelights物品（后注册物品，因为种子需要引用作物方块）
        DDItemInit.ITEMS.register(modEventBus);
        DDItemInit.CREATIVE_TABS.register(modEventBus);
    }

    public static class FoodItem extends Item {
        private final MobEffectInstance[] effects;

        public FoodItem(int nutrition, float saturation, MobEffectInstance[] effects) {
            super(new Item.Properties()
                    .food(new FoodProperties.Builder()
                            .nutrition(nutrition)
                            .saturationMod(saturation)
                            .build()));
            this.effects = effects;
        }

        @Override
        public ItemStack finishUsingItem(ItemStack stack, net.minecraft.world.level.Level world, net.minecraft.world.entity.LivingEntity entity) {
            ItemStack retval = super.finishUsingItem(stack, world, entity);
            for (MobEffectInstance effect : effects) {
                entity.addEffect(effect);
            }
            return retval;
        }
    }

    public static class SimpleFoodItem extends Item {
        public SimpleFoodItem(int nutrition, float saturation) {
            super(new Item.Properties()
                    .food(new FoodProperties.Builder()
                            .nutrition(nutrition)
                            .saturationMod(saturation)
                            .build()));
        }
    }
}
